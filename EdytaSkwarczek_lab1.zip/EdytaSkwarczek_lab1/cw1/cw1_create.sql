-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2024-03-14 18:14:16.372

-- tables
-- Table: Artykuly
CREATE TABLE Artykuly (
    IDZamowienia int  NOT NULL,
    IDPudelka text  NOT NULL,
    Sztuk int  NOT NULL,
    Pudelka_IDPudelka text  NOT NULL,
    Zamowienia_IDZamowienia int  NOT NULL,
    CONSTRAINT Artykuly_pk PRIMARY KEY (IDZamowienia,IDPudelka)
);

-- Table: Czekoladki
CREATE TABLE Czekoladki (
    IdCzekoladki text  NOT NULL,
    Nazwa text  NOT NULL,
    RodzajCzekolady text  NOT NULL,
    RodzajOrzechow text  NOT NULL,
    RodzajNadzienia text  NOT NULL,
    Opis text  NOT NULL,
    Koszt text  NOT NULL,
    Masa int  NOT NULL,
    CONSTRAINT Czekoladki_pk PRIMARY KEY (IdCzekoladki)
);

-- Table: Klienci
CREATE TABLE Klienci (
    IDKlienta int  NOT NULL,
    Nazwa text  NOT NULL,
    Ulica text  NOT NULL,
    Miejscowosc text  NOT NULL,
    Kod text  NOT NULL,
    Telefon text  NOT NULL,
    CONSTRAINT Klienci_pk PRIMARY KEY (IDKlienta)
);

-- Table: Pudelka
CREATE TABLE Pudelka (
    IDPudelka text  NOT NULL,
    Nazwa text  NOT NULL,
    Opis text  NOT NULL,
    Cena text  NOT NULL,
    Stan int  NOT NULL,
    CONSTRAINT Pudelka_pk PRIMARY KEY (IDPudelka)
);

-- Table: Zamowienia
CREATE TABLE Zamowienia (
    IDZamowienia int  NOT NULL,
    IDKlienta text  NOT NULL,
    DataRealizacji date  NOT NULL,
    Klienci_IDKlienta int  NOT NULL,
    CONSTRAINT Zamowienia_pk PRIMARY KEY (IDZamowienia)
);

-- Table: Zawartosc
CREATE TABLE Zawartosc (
    IDPudelka text  NOT NULL,
    IdCzekoladki text  NOT NULL,
    Sztuk int  NOT NULL,
    Czekoladki_IdCzekoladki text  NOT NULL,
    Pudelka_IDPudelka text  NOT NULL,
    CONSTRAINT Zawartosc_pk PRIMARY KEY (IDPudelka)
);

-- foreign keys
-- Reference: Artykuly_Pudelka (table: Artykuly)
ALTER TABLE Artykuly ADD CONSTRAINT Artykuly_Pudelka
    FOREIGN KEY (Pudelka_IDPudelka)
    REFERENCES Pudelka (IDPudelka)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Artykuly_Zamowienia (table: Artykuly)
ALTER TABLE Artykuly ADD CONSTRAINT Artykuly_Zamowienia
    FOREIGN KEY (Zamowienia_IDZamowienia)
    REFERENCES Zamowienia (IDZamowienia)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Zamowienia_Klienci (table: Zamowienia)
ALTER TABLE Zamowienia ADD CONSTRAINT Zamowienia_Klienci
    FOREIGN KEY (Klienci_IDKlienta)
    REFERENCES Klienci (IDKlienta)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Zawartosc_Czekoladki (table: Zawartosc)
ALTER TABLE Zawartosc ADD CONSTRAINT Zawartosc_Czekoladki
    FOREIGN KEY (Czekoladki_IdCzekoladki)
    REFERENCES Czekoladki (IdCzekoladki)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Zawartosc_Pudelka (table: Zawartosc)
ALTER TABLE Zawartosc ADD CONSTRAINT Zawartosc_Pudelka
    FOREIGN KEY (Pudelka_IDPudelka)
    REFERENCES Pudelka (IDPudelka)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- End of file.

